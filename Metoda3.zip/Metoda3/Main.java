public class Main {

	public static void main(String[] args) {
	
		CosCumparaturi mycos=new CosCumparaturi();

		   mycos.myProdus.add(new Produs(23.4));
		   mycos.myProdus.add(new Produs(24));
		   mycos.myProdus.add(new Produs(2));
		
		double rezultat;   
		rezultat=mycos.TotalCosCumparaturi();   
		System.out.println(rezultat);
	}
}
