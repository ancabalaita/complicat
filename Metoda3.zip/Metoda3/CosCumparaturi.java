// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 3/20/2018 11:15:11 AM
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   CosCumparaturi.java

import java.util.ArrayList;

public class CosCumparaturi
{
    public ArrayList<Produs> myProdus=new ArrayList<Produs>();;
    
    public CosCumparaturi()
    {

    }
    /*
     * @Metoda ce calculeaza pretul total produselor din cos
     */
    public double TotalCosCumparaturi()
    {  
    	double Suma=0;
    
    	 for(Produs prod: myProdus){
    		 Suma=Suma+prod.getPret();
    		 
 	   }
    	 return Suma;
    }

}