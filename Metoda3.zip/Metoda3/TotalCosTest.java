import static org.junit.Assert.*;

import org.junit.Test;

public class TotalCosTest {

	@Test
	public final void testMain() {
		CosCumparaturi mycos=new CosCumparaturi();

		   mycos.myProdus.add(new Produs(23.4));
		   mycos.myProdus.add(new Produs(24));
		   mycos.myProdus.add(new Produs(2));
		
		double rezultat;   
		rezultat=mycos.TotalCosCumparaturi();   
		System.out.println(rezultat);
		//fail("Not yet implemented"); 
	}

}
