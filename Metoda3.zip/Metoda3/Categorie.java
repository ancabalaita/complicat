// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 3/20/2018 11:15:10 AM
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   Categorie.java

import java.util.ArrayList;

public class Categorie
{

    public Categorie()
    {
    }

    public ArrayList getProdus()
    {
        return null;
    }

    public String nume;
    public ArrayList myProdus;
}