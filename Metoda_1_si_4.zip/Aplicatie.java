// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 3/20/2018 11:15:10 AM
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   Aplicatie.java
import java.util.ArrayList;

public class Aplicatie
{
    private static Aplicatie instance;
    private BazaDeDate myBazadedate;

    private Aplicatie()
    {
        instance = null;
    }

    public boolean ConfirmareLogIn(String uname, String pwd)
    {
    	ArrayList<Utilizator> bdd;
    	bdd = myBazadedate.getUtilizatori();
    	for (Utilizator i : bdd) {
    		if (i.getNumeUtilizator() == uname && i.getParola() == pwd) {
    			Utilizator util = new Utilizator(uname,pwd);
    			myBazadedate.addLogat(util);
    			return true;
    		}
    	}
    	return false;
    }
    
    public void Logout(Utilizator util) {
    	myBazadedate.removeLogat(util);
    }

    public static Aplicatie getInstance()
    {
        if(instance == null)
            instance = new Aplicatie();
        return instance;
    }
    

	public BazaDeDate getMyBazadedate() {
		return myBazadedate;
	}

	public void setMyBazadedate(BazaDeDate myBazadedate) {
		this.myBazadedate = myBazadedate;
	}
}