// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 3/20/2018 11:15:11 AM
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   Bazadedate.java

import java.util.ArrayList;

public class BazaDeDate
{
    private ArrayList<Utilizator> utilizatori = new ArrayList<Utilizator>();
    private ArrayList<Utilizator> logati = new ArrayList<Utilizator>();
    
    public void addLogat(Utilizator util) {
    	logati.add(util);
    }
    
    public boolean removeLogat(Utilizator util) {
    	for (Utilizator i : logati) {
    		if (i.getNumeUtilizator() == util.getNumeUtilizator())
    		{
    			logati.remove(i);
    			return true;
    		}
    	}
    	return false;
    }

    public BazaDeDate(ArrayList<Utilizator> utilizatori)
    {
    	this.setUtilizatori(utilizatori);
    }

	public ArrayList<Utilizator> getUtilizatori() {
		return utilizatori;
	}

	public void setUtilizatori(ArrayList<Utilizator> utilizatori) {
		this.utilizatori = utilizatori;
	}
}
