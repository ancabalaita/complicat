import java.util.ArrayList;
public class LabSase {

	public static void main(String[] args) {
			Aplicatie app = Aplicatie.getInstance();
			Utilizator teo = new Utilizator("teo","printesica");
			Utilizator delia = new Utilizator("domintoaca","nebuna");
			Utilizator jmq = new Utilizator("HACK","HACK");
			ArrayList<Utilizator> jmeckeri = new ArrayList<Utilizator>();
			jmeckeri.add(teo);
			jmeckeri.add(delia);
			BazaDeDate emag = new BazaDeDate(jmeckeri);
			app.setMyBazadedate(emag);
			teo.Login(app);
			delia.Login(app);
			jmq.Login(app);
			teo.Logout(app);
			
	}

}
