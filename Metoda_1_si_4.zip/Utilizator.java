// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 3/20/2018 11:15:10 AM
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   Utilizator.java


public class Utilizator
{
	private String numeUtilizator;
    private String parola;
    public Utilizator(String nume, String parola)
    {
    	this.setNumeUtilizator(nume);
    	this.setParola(parola);
    }

    /*public void getInstanta() {
		this.instanta = instanta.getInstance();
	}*/

	public void Login(Aplicatie instanta)
    {
    	boolean b = instanta.ConfirmareLogIn(numeUtilizator,parola);
    	if (b == true)
    		System.out.println("Esti smecher si te-ai logat, " + numeUtilizator);
    	else
    		System.out.println("Esti un mare HACKER, " + numeUtilizator);
    }

    public void Logout(Aplicatie instanta)
    {
        instanta.Logout(this);
        System.out.println("Pa - pa, " + this.getNumeUtilizator());
    }

	public String getNumeUtilizator() {
		return numeUtilizator;
	}

	public void setNumeUtilizator(String numeUtilizator) {
		this.numeUtilizator = numeUtilizator;
	}

	public String getParola() {
		return parola;
	}

	public void setParola(String parola) {
		this.parola = parola;
	}
}